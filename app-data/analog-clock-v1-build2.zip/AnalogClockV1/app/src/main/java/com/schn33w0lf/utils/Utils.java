package com.schn33w0lf.utils;

import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;

import java.util.List;

public class Utils {
    /**
     * Parse int (unsigned byte [0<=255]) to int (%)
     * @param value
     * @return int
     */
    public static int convertPercent(int value) {
        return (int)(value / 2.55);
    }
    /**
     * Parse int (%) to int (unsigned byte [0<=255])
     * @param value
     * @return int
     */
    public static int convertByte(int value) {
        return (int)(value * 2.55);
    }
    /**
     * Checks wether a variable is in an Array
     * @param needle
     * @param haystack
     * @return boolean
     */
    public static boolean inArray(String needle, String[] haystack) {
        boolean position = false;
        for (String n : haystack) {
            if (n == needle) {
                return true;
            }
        }
        return false;
    }
    public static boolean inArray(int needle, int[] haystack) {
        boolean position = false;
        for (int n : haystack) {
            if (n == needle) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the type of an BluetoothDevice.
     * @param device
     * @return String, one of those {"AUDIO_VIDEO", "COMPUTER", "HEALTH", "PHONE", "TOY", "WEARABLE", "UNKNOWN"}
     */
    public static String getBluetoothDeviceClass(BluetoothDevice device) {
        switch (device.getBluetoothClass().getMajorDeviceClass()) {
            case BluetoothClass.Device.AUDIO_VIDEO_CAMCORDER:
            case BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO:
            case BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE:
            case BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES:
            case BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO:
            case BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER:
            case BluetoothClass.Device.AUDIO_VIDEO_MICROPHONE:
            case BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO:
            case BluetoothClass.Device.AUDIO_VIDEO_SET_TOP_BOX:
            case BluetoothClass.Device.AUDIO_VIDEO_UNCATEGORIZED:
            case BluetoothClass.Device.AUDIO_VIDEO_VCR:
            case BluetoothClass.Device.AUDIO_VIDEO_VIDEO_CAMERA:
            case BluetoothClass.Device.AUDIO_VIDEO_VIDEO_CONFERENCING:
            case BluetoothClass.Device.AUDIO_VIDEO_VIDEO_DISPLAY_AND_LOUDSPEAKER:
            case BluetoothClass.Device.AUDIO_VIDEO_VIDEO_GAMING_TOY:
            case BluetoothClass.Device.AUDIO_VIDEO_VIDEO_MONITOR:
                return "AUDIO_VIDEO";
            case BluetoothClass.Device.COMPUTER_DESKTOP:
            case BluetoothClass.Device.COMPUTER_HANDHELD_PC_PDA:
            case BluetoothClass.Device.COMPUTER_LAPTOP:
            case BluetoothClass.Device.COMPUTER_PALM_SIZE_PC_PDA:
            case BluetoothClass.Device.COMPUTER_SERVER:
            case BluetoothClass.Device.COMPUTER_UNCATEGORIZED:
            case BluetoothClass.Device.COMPUTER_WEARABLE:
                return "COMPUTER;";
            case BluetoothClass.Device.HEALTH_BLOOD_PRESSURE:
            case BluetoothClass.Device.HEALTH_DATA_DISPLAY:
            case BluetoothClass.Device.HEALTH_GLUCOSE:
            case BluetoothClass.Device.HEALTH_PULSE_OXIMETER:
            case BluetoothClass.Device.HEALTH_PULSE_RATE:
            case BluetoothClass.Device.HEALTH_THERMOMETER:
            case BluetoothClass.Device.HEALTH_UNCATEGORIZED:
            case BluetoothClass.Device.HEALTH_WEIGHING:
                return "HEALTH";
            case BluetoothClass.Device.PHONE_CELLULAR:
            case BluetoothClass.Device.PHONE_CORDLESS:
            case BluetoothClass.Device.PHONE_ISDN:
            case BluetoothClass.Device.PHONE_MODEM_OR_GATEWAY:
            case BluetoothClass.Device.PHONE_SMART:
            case BluetoothClass.Device.PHONE_UNCATEGORIZED:
                return "PHONE";
            case BluetoothClass.Device.TOY_CONTROLLER:
            case BluetoothClass.Device.TOY_DOLL_ACTION_FIGURE:
            case BluetoothClass.Device.TOY_GAME:
            case BluetoothClass.Device.TOY_ROBOT:
            case BluetoothClass.Device.TOY_UNCATEGORIZED:
            case BluetoothClass.Device.TOY_VEHICLE:
                return "TOY";
            case BluetoothClass.Device.WEARABLE_GLASSES:
            case BluetoothClass.Device.WEARABLE_HELMET:
            case BluetoothClass.Device.WEARABLE_JACKET:
            case BluetoothClass.Device.WEARABLE_PAGER:
            case BluetoothClass.Device.WEARABLE_UNCATEGORIZED:
            case BluetoothClass.Device.WEARABLE_WRIST_WATCH:
                return "WEARABLE";
            default:
                return "UNKNOWN";
        }
    }
}
