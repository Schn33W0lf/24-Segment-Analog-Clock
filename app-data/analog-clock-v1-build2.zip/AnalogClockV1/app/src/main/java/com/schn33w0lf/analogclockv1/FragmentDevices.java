package com.schn33w0lf.analogclockv1;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.schn33w0lf.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@SuppressLint("ValidFragment")
public class FragmentDevices extends Fragment {
    private MainActivity mainActivity;
    private BluetoothAdapter bluetoothAdapter;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int REQUEST_ENABLE_BT = 0;
    private List<Integer> devicesListImage = new ArrayList<>();
    private List<String> devicesListName = new ArrayList<>();
    private List<String> devicesListMac = new ArrayList<>();
    private View button_disconnect;
    private boolean btConnected;

    @SuppressLint("ValidFragment")
    public FragmentDevices(MainActivity mainActivity, boolean btConnected) {
        this.mainActivity = mainActivity;
        this.btConnected = btConnected;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_devices, container, false);

        // Create RecyclerView
        RecyclerView devicesAvailableList = v.findViewById(R.id.devices_available_list);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        devicesAvailableList.setLayoutManager(layoutManager);
        devicesAvailableList.setItemAnimator(new DefaultItemAnimator());
        RecyclerViewDevices recyclerViewDevicesAdapter = new RecyclerViewDevices(devicesListImage, devicesListName, devicesListMac, mainActivity);
        devicesAvailableList.setAdapter(recyclerViewDevicesAdapter);

        // Create disconnect button
        button_disconnect = v.findViewById(R.id.button_device_disconnect);
        button_disconnect.setVisibility(btConnected ? View.VISIBLE : View.INVISIBLE);
        button_disconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call Main to disconnect from device
                mainActivity.disconnectDevice();
            }
        });

        // Ask for & enable Bluetooth, Update RecyclerView
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(getContext(), getString(R.string.error_bt_no_support), Toast.LENGTH_SHORT);
        } else {
            mainActivity.editMenu(Constants.message_edit_menu_disabled);
            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            if (bluetoothAdapter.isEnabled()) {
                mainActivity.editMenu(Constants.message_edit_menu_searching);
                // find pared devices
                Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
                if (pairedDevices.size() > 0) {
                    // There are paired devices. Get the name and address of each paired device.
                    for (BluetoothDevice device : pairedDevices) {
                        //String deviceName = device.getName();
                        //String deviceHardwareAddress = device.getAddress(); // MAC address
                        switch (Utils.getBluetoothDeviceClass(device)) {
                            case "AUDIO_VIDEO":
                                devicesListImage.add(R.drawable.ic_bluetooth_audio_black_24dp);
                                break;
                            case "COMPUTER":
                                devicesListImage.add(R.drawable.ic_computer_black_24dp);
                                break;
                            case "HEALTH":
                                devicesListImage.add(R.drawable.ic_favorite_black_24dp);
                                break;
                            case "PHONE":
                                devicesListImage.add(R.drawable.ic_phone_bluetooth_speaker_black_24dp);
                                break;
                            case "TOY":
                                devicesListImage.add(R.drawable.ic_toys_black_24dp);
                                break;
                            case "WEARABLE":
                                devicesListImage.add(R.drawable.ic_watch_black_24dp);
                                break;
                            default: // case "UNKNOWN":
                                devicesListImage.add(R.drawable.ic_bluetooth_black_24dp);
                                break;
                        }
                        devicesListName.add(device.getName());
                        devicesListMac.add(device.getAddress());
                    }
                } else {
                    devicesListImage.add(R.drawable.ic_bluetooth_disabled_black_24dp);
                    devicesListName.add(getString(R.string.error_bt_no_device));
                    devicesListMac.add(getString(R.string.error_bt_no_device_sub));
                }
            }
        }
        recyclerViewDevicesAdapter.notifyDataSetChanged();


        return v;
    }

    private class RecyclerViewDevices extends RecyclerView.Adapter<RecyclerViewDevices.ViewHolder> {
        private MainActivity mainActivity;
        private List<Integer> images;
        private List<String> names;
        private List<String> addresses;
        public RecyclerViewDevices(List<Integer> images, List<String> names, List<String> addresses, MainActivity mainActivity) {
            this.mainActivity = mainActivity;
            this.images = images;
            this.names = names;
            this.addresses = addresses;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_devices_item, parent, false);
            return new ViewHolder(itemView);
        }
        @Override
        public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int i) {
            viewHolder.image.setImageResource(this.images.get(i));
            viewHolder.name.setText(this.names.get(i));
            viewHolder.address.setText(this.addresses.get(i));
            viewHolder.item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int adapterPos = viewHolder.getAdapterPosition();
                    if(adapterPos != RecyclerView.NO_POSITION) {
                        mainActivity.selectDevice(addresses.get(adapterPos));
                    }
                }
            });
        }
        @Override
        public int getItemCount() {
            return images.size();
        }
        public class ViewHolder extends RecyclerView.ViewHolder {
            public ImageView image;
            public TextView name;
            public TextView address;
            public ConstraintLayout item;
            public ViewHolder(View itemView) {
                super(itemView);
                this.image = (ImageView)itemView.findViewById(R.id.image);
                this.name = (TextView)itemView.findViewById(R.id.name);
                this.address = (TextView)itemView.findViewById(R.id.address);
                this.item = itemView.findViewById(R.id.item);

            }
        }
    }
}
