package com.schn33w0lf.analogclockv1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import com.schn33w0lf.utils.Utils;

@SuppressLint("ValidFragment")
public class FragmentColors extends Fragment {
    private final MainActivity mainActivity;

    @SuppressLint("ValidFragment")
    public FragmentColors(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_colors, container, false);

        // Add items
        final SeekBar color_01_r = v.findViewById(R.id.color_01_r);
        final SeekBar color_01_g = v.findViewById(R.id.color_01_g);
        final SeekBar color_01_b = v.findViewById(R.id.color_01_b);
        final SeekBar color_01_a = v.findViewById(R.id.color_01_a);
        final Switch color_01_s = v.findViewById(R.id.color_01_s);
        final SeekBar color_02_r = v.findViewById(R.id.color_02_r);
        final SeekBar color_02_g = v.findViewById(R.id.color_02_g);
        final SeekBar color_02_b = v.findViewById(R.id.color_02_b);
        final SeekBar color_03_r = v.findViewById(R.id.color_03_r);
        final SeekBar color_03_g = v.findViewById(R.id.color_03_g);
        final SeekBar color_03_b = v.findViewById(R.id.color_03_b);
        final SeekBar color_04_0 = v.findViewById(R.id.color_04_0);
        final SeekBar color_04_1 = v.findViewById(R.id.color_04_1);
        final SeekBar color_04_2 = v.findViewById(R.id.color_04_2);
        // Toggle if required
        color_01_r.setProgress(Utils.convertPercent(mainActivity.colorBackground[0]));
        color_01_g.setProgress(Utils.convertPercent(mainActivity.colorBackground[1]));
        color_01_b.setProgress(Utils.convertPercent(mainActivity.colorBackground[2]));
        color_01_a.setProgress(Utils.convertPercent(mainActivity.brightnessBackground));
        color_01_s.setChecked(mainActivity.backgroundLighting);
        color_02_r.setProgress(Utils.convertPercent(mainActivity.colorPrimary[0]));
        color_02_g.setProgress(Utils.convertPercent(mainActivity.colorPrimary[1]));
        color_02_b.setProgress(Utils.convertPercent(mainActivity.colorPrimary[2]));
        color_03_r.setProgress(Utils.convertPercent(mainActivity.colorSecondary[0]));
        color_03_g.setProgress(Utils.convertPercent(mainActivity.colorSecondary[1]));
        color_03_b.setProgress(Utils.convertPercent(mainActivity.colorSecondary[2]));
        color_04_0.setProgress(Utils.convertPercent(mainActivity.brightnessOffset0));
        color_04_1.setProgress(Utils.convertPercent(mainActivity.brightnessOffset1));
        color_04_2.setProgress(Utils.convertPercent(mainActivity.brightnessOffset2));
        // Add event listener
        color_01_r.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorBackground[0] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('B');
            }
        });
        color_01_g.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorBackground[1] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('B');
            }
        });
        color_01_b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorBackground[2] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('B');
            }
        });
        color_01_a.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.brightnessBackground = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processBrightness('B');
            }
        });
        //<editor-fold desc="color_01_s.setOnClickListener(new View.OnClickListener() {...});">
        color_01_s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.backgroundLighting = color_01_s.isChecked();
                color_01_s.setText((mainActivity.backgroundLighting ? R.string.text_color_01_s_1 : R.string.text_color_01_s_0));
                processBrightness('L');
            }
        });
        //</editor-fold>
        color_02_r.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorPrimary[0] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('P');
            }
        });
        color_02_g.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorPrimary[1] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('P');
            }
        });
        color_02_b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorPrimary[2] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('P');
            }
        });
        color_03_r.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorSecondary[0] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('S');
            }
        });
        color_03_g.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorSecondary[1] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('S');
            }
        });
        color_03_b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.colorSecondary[2] = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processColor('S');
            }
        });
        color_04_0.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.brightnessOffset0 = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processBrightness('0');
            }
        });
        color_04_1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.brightnessOffset1 = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processBrightness('1');
            }
        });
        color_04_2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Change progress
                mainActivity.brightnessOffset2 = Utils.convertByte(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Do nothing
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Submit
                processBrightness('2');
            }
        });

        return v;
    }

    private void processColor(char target) {
        // Process colors
        switch (target) {
            case 'B':
                mainActivity.writeDevice("COLOR,B," + mainActivity.colorBackground[0] + ',' + mainActivity.colorBackground[1] + ',' + mainActivity.colorBackground[2]);
                break;
            case 'P':
                mainActivity.writeDevice("COLOR,P," + mainActivity.colorPrimary[0] + ',' + mainActivity.colorPrimary[1] + ',' + mainActivity.colorPrimary[2]);
                break;
            case 'S':
                mainActivity.writeDevice("COLOR,S," + mainActivity.colorSecondary[0] + ',' + mainActivity.colorSecondary[1] + ',' + mainActivity.colorSecondary[2]);
                break;

        }
    }
    private void processBrightness(char target) {
        // Process brightness
        switch (target) {
            case 'B':
                mainActivity.writeDevice("BRIGHTNESS,B," + mainActivity.brightnessBackground);
                break;
            case '0':
                mainActivity.writeDevice("BRIGHTNESS,0," + mainActivity.brightnessOffset0);
                break;
            case '1':
                mainActivity.writeDevice("BRIGHTNESS,1," + mainActivity.brightnessOffset1);
                break;
            case '2':
                mainActivity.writeDevice("BRIGHTNESS,2," + mainActivity.brightnessOffset2);
                break;
            case 'L':
                mainActivity.writeDevice("BRIGHTNESS,L," + (mainActivity.backgroundLighting ? 1 : 0));
                break;
        }
    }
}
