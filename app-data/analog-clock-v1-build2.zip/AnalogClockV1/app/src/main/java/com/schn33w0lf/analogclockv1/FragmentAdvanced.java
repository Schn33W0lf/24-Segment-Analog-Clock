package com.schn33w0lf.analogclockv1;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaScannerConnection;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

@SuppressLint("ValidFragment")
public class FragmentAdvanced extends Fragment {

    private final MainActivity mainActivity;

    Button advanced_01_b;
    EditText advanced_01_t;
    boolean advanced_01_t_changed = false;
    Button advanced_02_b_01;
    Button advanced_02_b_02;

    FileOutputStream outputStream;

    public FragmentAdvanced(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_advanced, container, false);

        advanced_01_b = v.findViewById(R.id.advanced_01_b);
        advanced_01_t = v.findViewById(R.id.advanced_01_t);
        advanced_02_b_01 = v.findViewById(R.id.advanced_02_b_01);
        advanced_02_b_02 = v.findViewById(R.id.advanced_02_b_02);

        advanced_01_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.writeDevice(advanced_01_t.getText().toString());
            }
        });
        advanced_01_t.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (!advanced_01_t_changed) {
                    advanced_01_t_changed = true;
                    advanced_01_t.setText("");
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        //<editor-fold desc="advanced_02_b_01.setOnClickListener(new View.OnClickListener((v) -> {">
        advanced_02_b_01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Request permission
                requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

                // Get folder, Create folder if nit created
                File appDir = new File(Constants.appDir);
                boolean success = true;
                if (!appDir.exists()){
                    success = appDir.mkdir();
                }
                if (success) {
                    try {

                        // Get data
                        //<editor-fold desc="// Create JSONObject {...}">
                        JSONObject json = new JSONObject();
                        JSONObject variables = new JSONObject();
                        JSONObject colors = new JSONObject();
                        JSONObject brightnesses = new JSONObject();
                        JSONObject colorBackground = new JSONObject();
                        JSONObject colorPrimary = new JSONObject();
                        JSONObject colorSecondary = new JSONObject();
                        colorBackground.put("r", mainActivity.colorBackground[0]);
                        colorBackground.put("g", mainActivity.colorBackground[1]);
                        colorBackground.put("b", mainActivity.colorBackground[2]);
                        colorPrimary.put("r", mainActivity.colorPrimary[0]);
                        colorPrimary.put("g", mainActivity.colorPrimary[1]);
                        colorPrimary.put("b", mainActivity.colorPrimary[2]);
                        colorSecondary.put("r", mainActivity.colorSecondary[0]);
                        colorSecondary.put("g", mainActivity.colorSecondary[1]);
                        colorSecondary.put("b", mainActivity.colorSecondary[2]);
                        brightnesses.put("background", mainActivity.brightnessBackground);
                        brightnesses.put("offset0", mainActivity.brightnessOffset0);
                        brightnesses.put("offset1", mainActivity.brightnessOffset1);
                        brightnesses.put("offset2", mainActivity.brightnessOffset2);
                        colors.put("background", colorBackground);
                        colors.put("primary", colorPrimary);
                        colors.put("secondary", colorSecondary);
                        json.put("variables", variables);
                        json.put("colors", colors);
                        json.put("brightnesses", brightnesses);
                        //</editor-fold>

                        // Creates a trace file in the primary external storage space of the
                        // current application.
                        // If the file does not exists, it is created.
                        File traceFile = new File(Constants.appDir + '/' + Constants.configFile);
                        if (!traceFile.exists())
                            traceFile.createNewFile();
                        // Adds a line to the trace file
                        BufferedWriter writer = new BufferedWriter(new FileWriter(traceFile, false /*append*/));
                        writer.write(json.toString());
                        writer.close();
                        // Refresh the data so it can seen when the device is plugged in a
                        // computer. You may have to unplug and replug the device to see the
                        // latest changes. This is not necessary if the user should not modify
                        // the files.
                        MediaScannerConnection.scanFile(getContext(),
                                new String[] { traceFile.toString() },
                                null,
                                null);

                    } catch (Exception e) {
                        Log.e("FragmentAdvanced.write", "Unable to write to file: " + e.getMessage());
                        Toast.makeText(getContext(), getString(R.string.error_file_cant_write), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Log.e("FragmentAdvanced.write", "Cant create dir");
                    Toast.makeText(getContext(), getString(R.string.error_file_cant_create), Toast.LENGTH_SHORT).show();
                }
            }
        });
        //</editor-fold>
        advanced_02_b_02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermissions(new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

                File traceFile = new File(Constants.appDir + '/' + Constants.configFile);
                if (traceFile.exists()) {
                    try {
                        StringBuilder text = new StringBuilder();
                        BufferedReader br = new BufferedReader(new FileReader(Constants.appDir + '/' + Constants.configFile));
                        String line;

                        while ((line = br.readLine()) != null) {
                            text.append(line);
                            text.append('\n');
                        }
                        br.close();

                        JSONObject json = new JSONObject(text.toString());

                        mainActivity.colorBackground[0] = json.getJSONObject("colors").getJSONObject("background").getInt("r");
                        mainActivity.colorBackground[1] = json.getJSONObject("colors").getJSONObject("background").getInt("g");
                        mainActivity.colorBackground[2] = json.getJSONObject("colors").getJSONObject("background").getInt("b");
                        mainActivity.colorPrimary[0] = json.getJSONObject("colors").getJSONObject("primary").getInt("r");
                        mainActivity.colorPrimary[1] = json.getJSONObject("colors").getJSONObject("primary").getInt("g");
                        mainActivity.colorPrimary[2] = json.getJSONObject("colors").getJSONObject("primary").getInt("b");
                        mainActivity.colorSecondary[0] = json.getJSONObject("colors").getJSONObject("secondary").getInt("r");
                        mainActivity.colorSecondary[1] = json.getJSONObject("colors").getJSONObject("secondary").getInt("g");
                        mainActivity.colorSecondary[2] = json.getJSONObject("colors").getJSONObject("secondary").getInt("b");
                        mainActivity.brightnessBackground = json.getJSONObject("brightnesses").getInt("background");
                        mainActivity.brightnessOffset0 = json.getJSONObject("brightnesses").getInt("offset0");
                        mainActivity.brightnessOffset1 = json.getJSONObject("brightnesses").getInt("offset1");
                        mainActivity.brightnessOffset2 = json.getJSONObject("brightnesses").getInt("offset2");

                    } catch (Exception e) {
                        Log.e("FragmentAdvanced.read", "Cant read file: " + e.getMessage());
                        Toast.makeText(getContext(), getString(R.string.error_file_cant_read), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getString(R.string.error_file_not_exist), Toast.LENGTH_SHORT).show();
                }

            }
        });

        return v;
    }
}
