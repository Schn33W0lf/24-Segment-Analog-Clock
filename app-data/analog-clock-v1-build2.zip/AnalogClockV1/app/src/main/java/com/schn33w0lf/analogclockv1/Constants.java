package com.schn33w0lf.analogclockv1;

import android.os.Environment;

public interface Constants {
    public final static String appDir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/AnalogClockV1";
    public final static String configFile = "config.json";
    public final static String message_edit_menu_disabled = "BT_DISABLED";
    public final static String message_edit_menu_searching = "BT_SEARCHING";
}
