package com.schn33w0lf.analogclockv1;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.googlesamples.android.bluetoothservice.BluetoothService;
import com.googlesamples.android.bluetoothservice.Constants;
import com.schn33w0lf.utils.Utils;

import static java.lang.Integer.parseInt;

public class MainActivity extends AppCompatActivity {
    // define variables (global)
    static View view;
    int site;
    public static MenuItem menuItem;
    private BottomNavigationView navigation;

    public boolean timerRunning;
    public int scoreLeft;
    public int scoreRight;
    public boolean modeToggle;
    public int mode;
    /** {int red, int green, int blue} */
    public int[] colorBackground = new int[3];
    public int[] colorPrimary = new int[3];
    public int[] colorSecondary = new int[3];
    public int brightnessBackground;
    public int brightnessOffset0;
    public int brightnessOffset1;
    public int brightnessOffset2;
    public boolean backgroundLighting;

    // define variables (bluetooth)
    private static final String TAG_BT = "MainActivity.BT";

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothService bluetoothService;
    private static final boolean secure = true;

    private static boolean btConnected = false;

    // listener
    //<editor-fold desc="BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener">
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            return site(item.getItemId(), false);
        }
    };
    //</editor-fold>

    //<editor-fold desc="private final Handler mHandler = new Handler() {}">
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case Constants.MESSAGE_STATE_CHANGE:
                    switch (msg.arg1) {
                        case BluetoothService.STATE_CONNECTED:
                            if (bluetoothService.isStableConnection()) {
                                writeDevice("PING");
                            }
                            break;
                        case BluetoothService.STATE_CONNECTING:
                            if (bluetoothService.isStableConnection()) {
                                findViewById(R.id.navigation_devices).performClick();
                                btConnected = false;
                                menuItem.setIcon(R.drawable.ic_bluetooth_black_24dp);
                            }
                            break;
                        case BluetoothService.STATE_LISTEN:
                        case BluetoothService.STATE_NONE:
                            findViewById(R.id.navigation_devices).performClick();
                            btConnected = false;
                            menuItem.setIcon(R.drawable.ic_bluetooth_searching_black_24dp);
                            break;
                    }
                    break;
                case Constants.MESSAGE_WRITE:
                    byte[] writeBuf = (byte[]) msg.obj;
                    // construct a string from the buffer
                    String writeMessage = new String(writeBuf);
                    Log.d(MainActivity.TAG_BT, "[BTOUT] Sending (" + writeMessage + ")");
                    break;
                case Constants.MESSAGE_READ:
                    //byte[] readBuf = (byte[]) msg.obj;
                    // construct a string from the valid bytes in the buffer
                    //String readMessage = new String(readBuf, 0, msg.arg1);
                    String readMessage = msg.getData().getString(Constants.MESSAGE_READ_STR);
                    Log.d(MainActivity.TAG_BT, "[BTOUT] Sending (" + readMessage + ")");
                    readDevice(msg.getData().getString(Constants.MESSAGE_READ_STR));
                    break;
                case Constants.MESSAGE_DEVICE_NAME:
                    // save the connected device's name
                    String mConnectedDeviceName = msg.getData().getString(Constants.DEVICE_NAME);
                    Toast.makeText(MainActivity.this, getString(R.string.info_bt_connected) + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                    break;
                case Constants.MESSAGE_TOAST:
                    /*
                     *  FOR NEW STRINGS:
                     * add <string name="message_foo">Foo</string> to res/strings.xml
                     * add public static final String MESSAGE_FOO = "message_foo"; to java/com.googlesamples.android.bluetoothservice/Constants.java
                     * call toast with:
                       Message msg = mHandler.obtainMessage(Constants.MESSAGE_TOAST);
                       Bundle bundle = new Bundle();
                       bundle.putString(Constants.TOAST, Constants.MESSAGE_FOO);
                       msg.setData(bundle);
                       mHandler.sendMessage(msg);
                     */
                    // Get res/string.xml string name as String [msg.getData().getString(Constants.TOAST)]
                    // Parse it to int and get the string defined in the xml
                    String message = msg.getData().getString(Constants.TOAST);
                    if (!(message == Constants.MESSAGE_CONNECTION_LOST && true)) {
                        Toast.makeText(MainActivity.this, getString(parseInt(message)), Toast.LENGTH_SHORT).show();
                        if (message == Constants.MESSAGE_CONNECTION_FAILED) {
                            site(R.id.navigation_devices, true);
                        }
                    }
            }
        }
    };
    //</editor-fold>

    // overrides
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        site(R.id.navigation_devices, true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menuItem; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        this.menuItem = menu.findItem(R.id.icon_bluetooth_status);
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bluetoothService.stop();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (!Utils.inArray(this.site, new int[] {R.id.navigation_devices, R.string.info_bt_connecting})) {
            site(R.id.navigation_devices, true);
        }
    }

    // methods
    public void editMenu(String status) {
        if (!btConnected) {
            switch (status) {
                case com.schn33w0lf.analogclockv1.Constants.message_edit_menu_searching:
                    if (menuItem != null) {
                        menuItem.setIcon(R.drawable.ic_bluetooth_searching_black_24dp);
                    }
                    break;
                case com.schn33w0lf.analogclockv1.Constants.message_edit_menu_disabled:
                    if (menuItem != null) {
                        menuItem.setIcon(R.drawable.ic_bluetooth_disabled_black_24dp);
                    }
                    break;
            }
        }
    }

    public boolean site(int site, boolean force) {
        FragmentTransaction t = getSupportFragmentManager().beginTransaction();
        boolean ret = false;
        if (this.site == R.string.info_bt_connecting && site == R.id.navigation_devices && !force) {
            ret = false;
        } else {
            if (this.btConnected || force || site == R.id.navigation_devices) {
                switch (site) {
                    case (R.id.navigation_devices):
                        setTitle(getString(R.string.app_name) + " | " + getString(R.string.title_devices));
                        t.replace(R.id.fragments, new FragmentDevices(this, btConnected));
                        ret = true;
                        break;
                    case (R.id.navigation_clock):
                        setTitle(getString(R.string.app_name) + " | " + getString(R.string.title_clock));
                        t.replace(R.id.fragments, new FragmentClock(this));
                        ret = true;
                        break;
                    case (R.id.navigation_colors):
                        setTitle(getString(R.string.app_name) + " | " + getString(R.string.title_colors));
                        t.replace(R.id.fragments, new FragmentColors(this));
                        ret = true;
                        break;
                    case (R.id.navigation_advanced):
                        setTitle(getString(R.string.app_name) + " | " + getString(R.string.title_advanced));
                        t.replace(R.id.fragments, new FragmentAdvanced(this));
                        ret = true;
                        break;
                    case (R.string.info_bt_connecting):
                        setTitle(getString(R.string.app_name) + " | " + getString(R.string.info_bt_connecting));
                        t.replace(R.id.fragments, new FragmentLoading(getString(R.string.info_bt_connecting2)));
                        ret = true;
                        break;
                }
            } else {
                Toast.makeText(this, getString(R.string.warning_site_no_device), Toast.LENGTH_SHORT).show();
            }
            if (ret) {
                this.site = site;
                t.commit();
            }
        }
        return ret;
    }

    public void disconnectDevice() {
        bluetoothService.stop(true);
        this.btConnected = false;
        Toast.makeText(this, getString(R.string.info_bt_disconnected), Toast.LENGTH_SHORT).show();
    }
    public void selectDevice(String address) {
        site(R.string.info_bt_connecting, true);
        Toast.makeText(this, getText(R.string.info_bt_connecting2), Toast.LENGTH_SHORT).show();
        /** Init BluetoothService, Connect, Switch site on success */
        bluetoothService = new BluetoothService(this, this.mHandler);
        // connect
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);
        bluetoothService.connect(device, this.secure);
    }

    public void writeDevice(String msg) {
        msg = "|" + msg + "|";
        bluetoothService.write(msg.getBytes());
    }

    private void readDevice(String readMessage) {
        if (readMessage != "") {
            String[] parameters = readMessage.split(",");
            switch (parameters[0]) {
                case "STATUS":
                    // Result of PING request
                    // Read status of clock (led values, modes, ...)
                    if (!btConnected) {
                        if (parameters[1].equals("4")) {
                            timerRunning = (parameters[2] == "true");
                            scoreLeft = parseInt(parameters[3]);
                            scoreRight = parseInt(parameters[4]);
                            modeToggle = (parameters[5] == "true");
                            mode = parseInt(parameters[6]);
                            colorBackground[0] = parseInt(parameters[7]);
                            colorBackground[1] = parseInt(parameters[8]);
                            colorBackground[2] = parseInt(parameters[9]);
                            colorPrimary[0] = parseInt(parameters[10]);
                            colorPrimary[1] = parseInt(parameters[11]);
                            colorPrimary[2] = parseInt(parameters[12]);
                            colorSecondary[0] = parseInt(parameters[13]);
                            colorSecondary[1] = parseInt(parameters[14]);
                            colorSecondary[2] = parseInt(parameters[15]);
                            brightnessBackground = parseInt(parameters[16]);
                            brightnessOffset0 = parseInt(parameters[17]);
                            brightnessOffset1 = parseInt(parameters[18]);
                            brightnessOffset2 = parseInt(parameters[19]);
                            backgroundLighting = (parameters[20] == "true");

                            btConnected = true;
                            findViewById(R.id.navigation_clock).performClick();
                            menuItem.setIcon(R.drawable.ic_bluetooth_connected_black_24dp);
                        } else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(this);
                            builder.setTitle(R.string.error_bt_device_not_supported_title);
                            builder.setMessage(R.string.error_bt_device_not_supported_text);
                            builder.create().show();
                        }
                        break;
                    }
                default:
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("MainActivity.readDevice@L221:");
                    builder.setMessage("DEBUG: Received message: '" + readMessage + "'.");
                    builder.create().show();
                    break;
            }
        }
    }
}
