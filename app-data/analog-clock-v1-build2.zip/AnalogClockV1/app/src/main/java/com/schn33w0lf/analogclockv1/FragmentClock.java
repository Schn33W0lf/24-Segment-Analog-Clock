package com.schn33w0lf.analogclockv1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import java.util.Calendar;

import static java.lang.Integer.parseInt;

@SuppressLint("ValidFragment")
public class FragmentClock extends Fragment {

    private final MainActivity mainActivity;

    Button clock_02_b_05;
    EditText clock_03_t_0;
    EditText clock_03_t_1;
    Switch clock_04_s;

    @SuppressLint("ValidFragment")
    public FragmentClock(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_clock, container, false);

        // Add items
        clock_02_b_05 = v.findViewById(R.id.clock_02_b_05);
        clock_03_t_0 = v.findViewById(R.id.clock_03_t_0);
        clock_03_t_1 = v.findViewById(R.id.clock_03_t_1);
        clock_04_s = v.findViewById(R.id.clock_04_s);
        // Toggle if required
        clock_03_t_0.setText("" + mainActivity.scoreLeft);
        clock_03_t_1.setText("" + mainActivity.scoreRight);
        if (mainActivity.timerRunning) {
            clock_02_b_05.setText(getString(R.string.text_clock_02_b_05_1));
        }
        clock_04_s.setChecked(mainActivity.modeToggle);
        // Add event listener
        ((Button)v.findViewById(R.id.clock_01_b)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process(1);
            }
        });
        ((Button)v.findViewById(R.id.clock_02_b_01)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process(2, 1);
            }
        });
        ((Button)v.findViewById(R.id.clock_02_b_02)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process(2, 2);
            }
        });
        ((Button)v.findViewById(R.id.clock_02_b_03)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process(2, 3);
            }
        });
        ((Button)v.findViewById(R.id.clock_02_b_04)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process(2, 4);
            }
        });
        clock_02_b_05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                process(2);
            }
        });
        clock_03_t_0.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Do nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Do nothing
            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    mainActivity.scoreLeft = parseInt(clock_03_t_0.getText().toString());
                    process(3);
                } catch (java.lang.NumberFormatException e) {}
            }
        });
        clock_03_t_1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Do nothing
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Do nothing
            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    mainActivity.scoreRight = parseInt(clock_03_t_1.getText().toString());
                    process(3);
                } catch (java.lang.NumberFormatException e) {}
            }
        });
        clock_04_s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 mainActivity.modeToggle = (clock_04_s.getText() == clock_04_s.getTextOn());
                 process(4);
            }
        });

        return v;
    }
    private void process(int position) {
        switch (position) {
            case 1:
                Calendar currentTime = Calendar.getInstance();
                mainActivity.writeDevice(
                        "RTC," +
                        currentTime.get(Calendar.YEAR) + ',' +
                        currentTime.get(Calendar.MONTH) + ',' +
                        currentTime.get(Calendar.DAY_OF_MONTH) + ',' +
                        currentTime.get(Calendar.HOUR_OF_DAY) + ',' +
                        currentTime.get(Calendar.MINUTE) + ',' +
                        currentTime.get(Calendar.SECOND)
                );
                break;
            // case 2: need values
            case 3:
                mainActivity.writeDevice("SCOREBOARD," + mainActivity.scoreLeft + ',' + mainActivity.scoreRight);
                break;
            case 4:
                mainActivity.writeDevice("MODETOGGLE");
                break;
        }
    }
    private void process(int position, int value) {
        switch(position) {
            // case 1: dont need values
            case 2:
                switch (value) {
                    case 1:
                        mainActivity.writeDevice("CLOCK");
                        break;
                    case 2:
                        mainActivity.writeDevice("TEMPERATURE");
                        break;
                    case 3:
                        mainActivity.writeDevice("HUMIDITY");
                        break;
                    case 4:
                        mainActivity.writeDevice("SCOREBOARD," + mainActivity.scoreLeft + mainActivity.scoreRight);
                        break;
                    case 5:
                        mainActivity.writeDevice("TIMER");
                        // Toggle between start & stop
                        clock_02_b_05.setText(getString((clock_02_b_05.getText() == getString(R.string.text_clock_02_b_05_0) ? R.string.text_clock_02_b_05_1 : R.string.text_clock_02_b_05_0)));
                        break;
                }
                break;
            // case 3: dont need values
            // case 4: dont need values
        }
    }
}
