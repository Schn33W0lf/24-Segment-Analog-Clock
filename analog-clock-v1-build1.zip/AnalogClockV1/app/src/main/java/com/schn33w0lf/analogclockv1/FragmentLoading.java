package com.schn33w0lf.analogclockv1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

@SuppressLint("ValidFragment")
public class FragmentLoading extends Fragment {
    private String message;

    @SuppressLint("ValidFragment")
    public FragmentLoading(String message) {
        this.message = message;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_loading, container, false);

        TextView message = v.findViewById(R.id.loading_text);
        message.setText(this.message);

        return v;

    }
}
